// Crypto utilities (à implémenter plus tard)
