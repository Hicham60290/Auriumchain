// Configuration management (à implémenter plus tard)
