// RocksDB storage implementation (à implémenter plus tard)
