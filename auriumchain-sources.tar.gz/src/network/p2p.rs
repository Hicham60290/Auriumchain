// P2P network implementation (à implémenter plus tard)
