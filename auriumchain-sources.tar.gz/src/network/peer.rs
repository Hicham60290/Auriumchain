// Peer management (à implémenter plus tard)
